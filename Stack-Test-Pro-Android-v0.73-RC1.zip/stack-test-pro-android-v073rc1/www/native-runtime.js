// Build-time placeholder. `npm run native:bundle` replaces this with the Capacitor native bridge.
